# TAMUOnCHAIN-identity-layer
Minimal onchain identity &amp;referral attribution layer using SIWE (EIP-4361) . Phase1 focus on identity verification.
